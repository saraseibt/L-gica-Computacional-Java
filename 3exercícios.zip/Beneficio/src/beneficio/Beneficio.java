package beneficio;

import java.util.Scanner;

public class Beneficio {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        double renda;
        int dependentes;
        char flagFimProg = 'N';

        while (flagFimProg == 'N') {
            System.out.print("Digite sua renda mensal: ");
            renda = scanner.nextDouble();

            System.out.print("Digite o número de dependentes: ");
            dependentes = scanner.nextInt();

            if (dependentes > 3) {
                if (renda <= 1500) {
                    System.out.println("Classe baixa - tem direito ao benefício.");
                } else if (renda <= 3500) {
                    System.out.println("Classe média baixa - análise de elegibilidade.");
                } else if (renda <= 7500) {
                    System.out.println("Classe média - sem direito ao benefício.");
                } else {
                    System.out.println("Classe alta - sem direito ao benefício.");
                }
            } else if (renda <= 1500) {
                System.out.println("Classe baixa - tem direito ao benefício.");
            } else if (renda <= 3500) {
                System.out.println("Classe média baixa - análise de elegibilidade.");
            } else if (renda <= 7500) {
                System.out.println("Classe média - sem direito ao benefício.");
            }
            System.out.println("Finaliza o programa?(S/N)");
            flagFimProg = scanner.next().toUpperCase().charAt(0);
            while (flagFimProg != 'N' && flagFimProg != 'S') {
                System.out.println("Opcao Invalida (S/N)");
                flagFimProg = scanner.next().toUpperCase().charAt(0);
            }
        }
        scanner.close();

    }

}
