import java.util.Scanner;
public class CalculoImposto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double salarioBruto, valorImposto = 0.0;
        String flagFimProg = "N";

        while (flagFimProg.equals("N")) {
            System.out.print("Salario Bruto: ");
            salarioBruto = scanner.nextDouble();

            if (salarioBruto <= 2500) {
                System.out.println("Isento de Imposto.");
            } else if (salarioBruto >= 2500.01 && salarioBruto <= 5000) {
                valorImposto = salarioBruto * 0.10;
            } else if (salarioBruto >= 5000.01 && salarioBruto <= 10000) {
                valorImposto = salarioBruto * 0.20;
            } else {
                valorImposto = salarioBruto * 0.275;
            }

            valorImposto = Math.round(valorImposto * 100.0) / 100.0;

            System.out.printf("\nSalario Bruto: %.2f", salarioBruto);
            System.out.printf("\nImposto a pagar: %.2f", valorImposto);
            System.out.printf("\nSalario Liquido: %.2f", (salarioBruto - valorImposto));

           
            try {
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("\n\n\n\n\n\n\n\n\n\n");
            
            System.out.print("Finalize? (S/N): ");
            flagFimProg = scanner.next().toUpperCase();
        }
        
        scanner.close();
    }
}